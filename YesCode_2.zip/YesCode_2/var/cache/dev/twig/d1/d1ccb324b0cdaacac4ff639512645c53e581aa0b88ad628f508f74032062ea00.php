<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* account/show.html.twig */
class __TwigTemplate_a13c4dee54fbb873ba08c77c24b711750a41464ae2fefd3b892f2232c1ad77ad extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "account/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "account/show.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "account/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 4, $this->source); })()), "fullname", [], "any", false, false, false, 4), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "\t<div class=\"container\">
\t\t<h1 class=\"my-5 text-center\">";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 9, $this->source); })()), "fullname", [], "any", false, false, false, 9), "html", null, true);
        echo "</h1>
\t\t<div class=\"row\">
\t\t\t<div class=\"col-4\">
\t\t\t\t<p class=\"text-left\">email:
\t\t\t\t\t";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 13, $this->source); })()), "email", [], "any", false, false, false, 13), "html", null, true);
        echo "
\t\t\t\t</p>
\t\t\t</div>
\t\t";
        // line 16
        if (((isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 16, $this->source); })()) === twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16))) {
            echo "\t
\t\t\t<div>
                <a href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_edit", ["slug" => twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 18, $this->source); })()), "slug", [], "any", false, false, false, 18)]), "html", null, true);
            echo "\" class=\"btn btn-info mx-2\">
                    Modifier mon profil
                    <i class=\"fa fa-pen\"></i>
                </a>
                <form class=\"d-inline\" action=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_delete", ["slug" => twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 22, $this->source); })()), "slug", [], "any", false, false, false, 22)]), "html", null, true);
            echo "\" 
\t\t\t\t\tonsubmit=\"return confirm('Etes vous sur de vouloir supprimer cette article ?');\">
                    <button class=\"btn btn-danger mx-2\">
                            Supprimer mon profil
                        <i class=\"fa fa-trash\"></i>
                    </button>
                </form>
\t\t\t</div>
\t\t";
        }
        // line 31
        echo "\t\t</div>

\t\t<p class=\"my-2 border p-2\">";
        // line 33
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 33, $this->source); })()), "presentation", [], "any", false, false, false, 33), "html", null, true);
        echo "</p>

\t\t<img src=\"";
        // line 35
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 35, $this->source); })()), "avatar", [], "any", false, false, false, 35), "html", null, true);
        echo "\" alt=\"photo de l'article ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 35, $this->source); })()), "firstname", [], "any", false, false, false, 35), "html", null, true);
        echo "\" width=\"450px\">

\t\t";
        // line 37
        if ((1 === twig_compare(twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 37, $this->source); })()), "articles", [], "any", false, false, false, 37)), 0))) {
            // line 38
            echo "
\t\t\t\t<h2 class=\"my-5\">Mes articles en lignes</h2>

\t\t\t\t<div class=\"row flex-lg-row flex-xl-row flex-column border bg-light\">
\t\t\t\t\t";
            // line 42
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 42, $this->source); })()), "articles", [], "any", false, false, false, 42));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
                // line 43
                echo "\t\t\t\t\t\t";
                $this->loadTemplate("partials/card.article.html.twig", "account/show.html.twig", 43)->display($context);
                // line 44
                echo "\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 45
            echo "\t\t\t\t</div>

\t\t\t";
        } else {
            // line 48
            echo "
\t\t\t\t<div class=\"border text-center bg-light my-5\">
\t\t\t\t\t<h2 class=\"my-5\">Vous n'avez pas encore publié d'article !</h2>
\t\t\t\t\t<a class=\"nav-link text-center h2\" href=\"";
            // line 51
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_create");
            echo "\">
\t\t\t\t\t\t\t<i class=\"fa fa-pen fa-1.5x\"></i>
\t\t\t\t\t\t\tEcrire votre premier article !
\t\t\t\t\t</a>
\t\t\t\t</div>

\t\t";
        }
        // line 58
        echo "\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "account/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 58,  200 => 51,  195 => 48,  190 => 45,  176 => 44,  173 => 43,  156 => 42,  150 => 38,  148 => 37,  141 => 35,  136 => 33,  132 => 31,  120 => 22,  113 => 18,  108 => 16,  102 => 13,  95 => 9,  92 => 8,  82 => 7,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}
\t{{user.fullname}}
{% endblock %}

{% block body %}
\t<div class=\"container\">
\t\t<h1 class=\"my-5 text-center\">{{user.fullname}}</h1>
\t\t<div class=\"row\">
\t\t\t<div class=\"col-4\">
\t\t\t\t<p class=\"text-left\">email:
\t\t\t\t\t{{ user.email}}
\t\t\t\t</p>
\t\t\t</div>
\t\t{% if user is same as(app.user) %}\t
\t\t\t<div>
                <a href=\"{{ path('account_edit' , {'slug': user.slug } ) }}\" class=\"btn btn-info mx-2\">
                    Modifier mon profil
                    <i class=\"fa fa-pen\"></i>
                </a>
                <form class=\"d-inline\" action=\"{{ path('account_delete' , {'slug': user.slug } ) }}\" 
\t\t\t\t\tonsubmit=\"return confirm('Etes vous sur de vouloir supprimer cette article ?');\">
                    <button class=\"btn btn-danger mx-2\">
                            Supprimer mon profil
                        <i class=\"fa fa-trash\"></i>
                    </button>
                </form>
\t\t\t</div>
\t\t{% endif %}
\t\t</div>

\t\t<p class=\"my-2 border p-2\">{{user.presentation}}</p>

\t\t<img src=\"{{user.avatar}}\" alt=\"photo de l'article {{user.firstname}}\" width=\"450px\">

\t\t{% if user.articles | length > 0 %}

\t\t\t\t<h2 class=\"my-5\">Mes articles en lignes</h2>

\t\t\t\t<div class=\"row flex-lg-row flex-xl-row flex-column border bg-light\">
\t\t\t\t\t{% for article in user.articles %}
\t\t\t\t\t\t{% include \"partials/card.article.html.twig\" %}
\t\t\t\t\t{% endfor %}
\t\t\t\t</div>

\t\t\t{% else %}

\t\t\t\t<div class=\"border text-center bg-light my-5\">
\t\t\t\t\t<h2 class=\"my-5\">Vous n'avez pas encore publié d'article !</h2>
\t\t\t\t\t<a class=\"nav-link text-center h2\" href=\"{{ path('article_create') }}\">
\t\t\t\t\t\t\t<i class=\"fa fa-pen fa-1.5x\"></i>
\t\t\t\t\t\t\tEcrire votre premier article !
\t\t\t\t\t</a>
\t\t\t\t</div>

\t\t{% endif %}
\t</div>
{% endblock %}
", "account/show.html.twig", "C:\\Users\\Sonia\\Desktop\\symfony-lyon\\YesCode_2\\templates\\account\\show.html.twig");
    }
}
