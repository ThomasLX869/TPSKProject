<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/card.article.html.twig */
class __TwigTemplate_f8b140f65dffdac78df1a6f23c1ea63dd03744ea10982b7c2e1978d5d8be05fb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/card.article.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/card.article.html.twig"));

        // line 1
        echo "<div class=\"col-xl-4 col-lg-4 col-md-8 col-sm-12 m-auto text-center\">
    <div class=\"card bg-light my-5 shadow \">
        <h3 class=\"card-header\">";
        // line 3
        echo twig_escape_filter($this->env, twig_title_string_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 3, $this->source); })()), "title", [], "any", false, false, false, 3)), "html", null, true);
        echo "</h3>
        <img height=\"350px\" class=\"rounded-circle border border-success m-2\" src=\"";
        // line 4
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 4, $this->source); })()), "image", [], "any", false, false, false, 4), "html", null, true);
        echo "\" alt=\"Card image\">
        <div class=\"card-body\">
            <p class=\"card-text\">";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 6, $this->source); })()), "intro", [], "any", false, false, false, 6), "html", null, true);
        echo "</p>
            <a href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_show", ["slug" => twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 7, $this->source); })()), "slug", [], "any", false, false, false, 7)]), "html", null, true);
        echo "\" class=\"btn btn-primary rounded\">Lire la suite</a>
        <div class=\"my-3\">
                <a href=\"#\" class=\"card-link\">";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 9, $this->source); })()), "author", [], "any", false, false, false, 9), "fullname", [], "any", false, false, false, 9), "html", null, true);
        echo "</a>
        </div>
        </div>
        <div class=\"card-footer text-muted\">
        ";
        // line 13
        if (twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 13, $this->source); })()), "createdAt", [], "any", false, false, false, 13)) {
            // line 14
            echo "        ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["article"]) || array_key_exists("article", $context) ? $context["article"] : (function () { throw new RuntimeError('Variable "article" does not exist.', 14, $this->source); })()), "createdAt", [], "any", false, false, false, 14), "d/m/Y à H:i"), "html", null, true);
            echo "
        ";
        } else {
            // line 16
            echo "            Il y a 2 jours
        ";
        }
        // line 18
        echo "        </div>
    </div>
</div>

";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partials/card.article.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 18,  80 => 16,  74 => 14,  72 => 13,  65 => 9,  60 => 7,  56 => 6,  51 => 4,  47 => 3,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"col-xl-4 col-lg-4 col-md-8 col-sm-12 m-auto text-center\">
    <div class=\"card bg-light my-5 shadow \">
        <h3 class=\"card-header\">{{article.title | title}}</h3>
        <img height=\"350px\" class=\"rounded-circle border border-success m-2\" src=\"{{article.image}}\" alt=\"Card image\">
        <div class=\"card-body\">
            <p class=\"card-text\">{{article.intro}}</p>
            <a href=\"{{ path('article_show', {'slug':article.slug}) }}\" class=\"btn btn-primary rounded\">Lire la suite</a>
        <div class=\"my-3\">
                <a href=\"#\" class=\"card-link\">{{ article.author.fullname }}</a>
        </div>
        </div>
        <div class=\"card-footer text-muted\">
        {% if article.createdAt %}
        {{ article.createdAt | date('d/m/Y à H:i') }}
        {% else %}
            Il y a 2 jours
        {% endif %}
        </div>
    </div>
</div>

", "partials/card.article.html.twig", "C:\\Users\\Sonia\\Desktop\\symfony-lyon\\YesCode_2\\templates\\partials\\card.article.html.twig");
    }
}
