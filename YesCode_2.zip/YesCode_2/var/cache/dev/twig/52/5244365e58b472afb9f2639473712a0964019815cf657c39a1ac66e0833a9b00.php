<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/header.html.twig */
class __TwigTemplate_86702658a8b1af2bf39b31cba592223adad919782d67d4b8091de7c73fe41591 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/header.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/header.html.twig"));

        // line 1
        echo "<header>
\t<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">

\t\t<a class=\"navbar-brand\" href=\"";
        // line 4
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home_page");
        echo "\">
\t\t\tYesCode
\t\t</a>

\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor01\" aria-controls=\"navbarColor01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t</button>

\t\t<div class=\"collapse navbar-collapse\" id=\"navbarColor01\">
\t\t\t<ul class=\"navbar-nav mr-auto\">

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 16
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home_page");
        echo "\">
\t\t\t\t\t\t<i class=\"fa fa-home\"></i>
\t\t\t\t\t\tAccueil
\t\t\t\t\t</a>
\t\t\t\t</li>

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 23
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("articles_index");
        echo "\">
\t\t\t\t\t\t<i class=\"fa fa-newspaper\"></i>
\t\t\t\t\t\tArticles
\t\t\t\t\t</a>
\t\t\t\t</li>

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("users_list");
        echo "\">
\t\t\t\t\t\t<i class=\"fa fa-list\"></i>
\t\t\t\t\t\tListe des membres
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t";
        // line 35
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 35, $this->source); })()), "user", [], "any", false, false, false, 35)) {
            // line 36
            echo "\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"";
            // line 37
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_create");
            echo "\">
\t\t\t\t\t\t\t<i class=\"fa fa-pen\"></i>
\t\t\t\t\t\t\tEcrire un article
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t";
        }
        // line 43
        echo "\t\t\t</ul>
\t\t

\t\t\t";
        // line 46
        $context["user"] = ["firstname" => "amar", "lastname" => "bou", "role" => "admin", "isConnected" => false];
        // line 47
        echo "
\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t";
        // line 49
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 49, $this->source); })()), "user", [], "any", false, false, false, 49)) {
            // line 50
            echo "\t\t\t\t\t<li class=\"nav-item dropdown\">
\t\t\t\t\t\t<a class=\"nav-link dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t";
            // line 53
            echo twig_escape_filter($this->env, twig_title_string_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 53, $this->source); })()), "user", [], "any", false, false, false, 53), "firstname", [], "any", false, false, false, 53)), "html", null, true);
            echo "
\t\t\t\t\t\t\t";
            // line 54
            echo twig_escape_filter($this->env, twig_title_string_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 54, $this->source); })()), "user", [], "any", false, false, false, 54), "lastname", [], "any", false, false, false, 54)), "html", null, true);
            echo "
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"dropdown-menu dropdown-menu-right\">
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Mon Profil</a>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"";
            // line 58
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_create");
            echo "\">Ecrire un article</a>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Mes articles</a>
\t\t\t\t\t\t\t";
            // line 60
            if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 60, $this->source); })()), "role", [], "any", false, false, false, 60), "admin"))) {
                // line 61
                echo "\t\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Espace Admin</a>
\t\t\t\t\t\t\t";
            }
            // line 63
            echo "\t\t\t\t\t\t\t<div class=\"dropdown-divider\"></div>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"";
            // line 64
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_logout");
            echo "\">Déconnexion</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</li>
\t\t\t\t";
        } else {
            // line 68
            echo "\t\t\t\t\t<li class=\"nav-item mx-3\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"";
            // line 69
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_create");
            echo "\">
\t\t\t\t\t\t\t<i class=\"fas fa-user-plus mx-2\"></i>
\t\t\t\t\t\t\tinscription
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item \">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"";
            // line 75
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_login");
            echo "\">
\t\t\t\t\t\t\t<i class=\"fas fa-sign-in-alt mx-2\"></i>
\t\t\t\t\t\t\tconnexion
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t";
        }
        // line 81
        echo "\t\t\t</ul>
\t\t</div>

\t</nav>
</header>

";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 87, $this->source); })()), "flashes", [], "any", false, false, false, 87));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 88
            echo "\t<div class=\"container text-center my-5\">
\t\t<div class=\"alert alert-";
            // line 89
            echo twig_escape_filter($this->env, $context["label"], "html", null, true);
            echo "\">
\t\t\t";
            // line 90
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 91
                echo "\t\t\t\t<p>";
                echo $context["message"];
                echo "</p>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 93
            echo "\t\t</div>
\t</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "





";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partials/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 96,  208 => 93,  199 => 91,  195 => 90,  191 => 89,  188 => 88,  184 => 87,  176 => 81,  167 => 75,  158 => 69,  155 => 68,  148 => 64,  145 => 63,  141 => 61,  139 => 60,  134 => 58,  127 => 54,  123 => 53,  118 => 50,  116 => 49,  112 => 47,  110 => 46,  105 => 43,  96 => 37,  93 => 36,  91 => 35,  83 => 30,  73 => 23,  63 => 16,  48 => 4,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header>
\t<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">

\t\t<a class=\"navbar-brand\" href=\"{{path(\"home_page\")}}\">
\t\t\tYesCode
\t\t</a>

\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor01\" aria-controls=\"navbarColor01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t</button>

\t\t<div class=\"collapse navbar-collapse\" id=\"navbarColor01\">
\t\t\t<ul class=\"navbar-nav mr-auto\">

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"{{path(\"home_page\")}}\">
\t\t\t\t\t\t<i class=\"fa fa-home\"></i>
\t\t\t\t\t\tAccueil
\t\t\t\t\t</a>
\t\t\t\t</li>

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('articles_index') }}\">
\t\t\t\t\t\t<i class=\"fa fa-newspaper\"></i>
\t\t\t\t\t\tArticles
\t\t\t\t\t</a>
\t\t\t\t</li>

\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('users_list') }}\">
\t\t\t\t\t\t<i class=\"fa fa-list\"></i>
\t\t\t\t\t\tListe des membres
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t{% if app.user %}
\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('article_create') }}\">
\t\t\t\t\t\t\t<i class=\"fa fa-pen\"></i>
\t\t\t\t\t\t\tEcrire un article
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t{% endif %}
\t\t\t</ul>
\t\t

\t\t\t{% set user = {\"firstname\":\"amar\", \"lastname\": \"bou\", \"role\": \"admin\" , 'isConnected': false} %}

\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t{% if app.user %}
\t\t\t\t\t<li class=\"nav-item dropdown\">
\t\t\t\t\t\t<a class=\"nav-link dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t{{ app.user.firstname | title }}
\t\t\t\t\t\t\t{{ app.user.lastname | title }}
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"dropdown-menu dropdown-menu-right\">
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Mon Profil</a>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"{{ path('article_create') }}\">Ecrire un article</a>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Mes articles</a>
\t\t\t\t\t\t\t{% if user.role == \"admin\" %}
\t\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#\">Espace Admin</a>
\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t<div class=\"dropdown-divider\"></div>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"{{ path('account_logout') }}\">Déconnexion</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</li>
\t\t\t\t{% else %}
\t\t\t\t\t<li class=\"nav-item mx-3\">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('account_create') }}\">
\t\t\t\t\t\t\t<i class=\"fas fa-user-plus mx-2\"></i>
\t\t\t\t\t\t\tinscription
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"nav-item \">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('account_login') }}\">
\t\t\t\t\t\t\t<i class=\"fas fa-sign-in-alt mx-2\"></i>
\t\t\t\t\t\t\tconnexion
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t{% endif %}
\t\t\t</ul>
\t\t</div>

\t</nav>
</header>

{% for label,messages in app.flashes %}
\t<div class=\"container text-center my-5\">
\t\t<div class=\"alert alert-{{ label }}\">
\t\t\t{% for message in messages %}
\t\t\t\t<p>{{ message | raw }}</p>
\t\t\t{% endfor %}
\t\t</div>
\t</div>
{% endfor %}






", "partials/header.html.twig", "C:\\Users\\Sonia\\Desktop\\symfony-lyon\\YesCode_2\\templates\\partials\\header.html.twig");
    }
}
